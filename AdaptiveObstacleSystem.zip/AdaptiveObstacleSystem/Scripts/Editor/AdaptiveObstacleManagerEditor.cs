#if UNITY_EDITOR
using UnityEngine;
using UnityEditor;
using Game.Obstacles;

[CustomEditor(typeof(AdaptiveObstacleManager))]
public class AdaptiveObstacleManagerEditor : Editor
{
    private Vector3 spawnPosition = Vector3.zero;

    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        AdaptiveObstacleManager manager = (AdaptiveObstacleManager)target;
        GUILayout.Space(10);
        GUILayout.Label("Manual Placement (Editor Tool)", EditorStyles.boldLabel);

        spawnPosition = EditorGUILayout.Vector3Field("Spawn Position", spawnPosition);

        if (GUILayout.Button("Spawn Stationary"))
        {
            manager.SpawnObstacleAt(spawnPosition, Quaternion.identity, false);
        }

        if (GUILayout.Button("Spawn Moving"))
        {
            manager.SpawnObstacleAt(spawnPosition, Quaternion.identity, true);
        }
    }
}
#endif