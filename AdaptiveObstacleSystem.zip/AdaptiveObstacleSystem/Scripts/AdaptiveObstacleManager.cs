using UnityEngine;

namespace Game.Obstacles
{
    
    /// <summary>
    /// Adaptive implementation that ramps obstacle count, type, and behavior
    /// according to the current difficulty level.
    /// </summary>
    public class AdaptiveObstacleManager : BaseObstacleManager
    {
        [Header("Difficulty Settings")]
        public int baseObstacleCount = 3;
        public int obstacleIncreasePerLevel = 2;
        public float baseMovingSpeed = 2f;
        public float movingSpeedPerLevel = 0.5f;

        /// <summary>
        /// Main entry point for creating a level’s obstacle layout.
        /// </summary>
        public override void GenerateObstacles(int difficultyLevel)
        {
            // Always clean previous obstacles
            ClearObstacles();

            // Determine total number for this level
            int total = baseObstacleCount + (obstacleIncreasePerLevel * (difficultyLevel - 1));

            // By default, everything is stationary
            int stationaryCount = total;
            int movingCount = 0;

            // Starting at level 2, add moving obstacles
            if (difficultyLevel > 1)
            {
                // Example formula: 1 new moving obstacle per level after 1
                movingCount = Mathf.Min(difficultyLevel - 1, total / 2);
                stationaryCount = total - movingCount;
            }

            // ----- Spawn stationary -----
            for (int i = 0; i < stationaryCount; i++)
                SpawnObstacle(stationaryPrefab);

            // ----- Spawn moving -----
            for (int i = 0; i < movingCount; i++)
            {
                var obj = SpawnObstacle(movingPrefab);
                var mover = obj.GetComponent<MovingObstacle>();
                if (mover != null)
                {
                    mover.pointA = obj.transform.position;
                    mover.pointB = obj.transform.position + new Vector3(
                        Random.Range(-3f, 3f), 0, Random.Range(-3f, 3f)
                    );
                    mover.speed = baseMovingSpeed + movingSpeedPerLevel * (difficultyLevel - 1);
                }
            }

            Debug.Log($"[ObstacleManager] Level {difficultyLevel}: {stationaryCount} stationary, {movingCount} moving.");
        }
        
        // For Manual obstacle placement and editor
        public void SpawnObstacleAt(Vector3 position, Quaternion rotation, bool isMoving = false)
        {
            GameObject prefab = isMoving ? movingPrefab : stationaryPrefab;
            if (prefab == null)
            {
                Debug.LogWarning("[ObstacleManager] Missing obstacle prefab reference.");
                return;
            }

            GameObject obstacle = Instantiate(prefab, position, rotation, transform);
            obstacle.name = isMoving ? "MovingObstacle_Manual" : "StationaryObstacle_Manual";

            // Optional: If it's a moving obstacle, give it some motion parameters
            if (isMoving)
            {
                var mover = obstacle.GetComponent<MovingObstacle>();
                if (mover != null)
                {
                    mover.pointA = obstacle.transform.position;
                    mover.pointB = obstacle.transform.position + new Vector3(
                        Random.Range(-3f, 3f), 0, Random.Range(-3f, 3f)
                    );
                    mover.speed = baseMovingSpeed;
                }
            }

            Debug.Log($"[ObstacleManager] Manually spawned {(isMoving ? "moving" : "stationary")} obstacle at {position}");
        }
        
        /* To test placer
        private void Update()
        {
            // Press "O" to spawn a stationary obstacle
            if (Input.GetKeyDown(KeyCode.O))
            {
                SpawnObstacleAt(new Vector3(0, 0.5f, 0), Quaternion.identity, false);
            }

            // Press "P" to spawn a moving obstacle
            if (Input.GetKeyDown(KeyCode.P))
            {
                SpawnObstacleAt(new Vector3(3, 0.5f, 0), Quaternion.identity, true);
            }
        }
        */
    }
}

