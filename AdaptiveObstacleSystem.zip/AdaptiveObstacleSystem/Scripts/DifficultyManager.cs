using UnityEngine;

public class DifficultyManager : MonoBehaviour
{
    public static DifficultyManager Instance { get; private set; }

    public int SelectedDifficulty { get; private set; } = 1;
    public int SelectedLevel { get; private set; } = 1;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void SetDifficulty(int diff)
    {
        SelectedDifficulty = Mathf.Clamp(diff, 1, 5);
        Debug.Log($"[DifficultyManager] Difficulty set to {SelectedDifficulty}");
    }

    public void SetLevel(int lvl)
    {
        SelectedLevel = Mathf.Max(1, lvl);
        Debug.Log($"[DifficultyManager] Level set to {SelectedLevel}");
    }
}