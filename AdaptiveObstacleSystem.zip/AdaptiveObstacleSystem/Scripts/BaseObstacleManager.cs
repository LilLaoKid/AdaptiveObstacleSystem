using UnityEngine;
using System.Collections.Generic;

namespace Game.Obstacles
{
    /// <summary>
    /// Abstract base class for obstacle managers.
    /// Handles registration, spawning, cleanup, and provides reusable hooks.
    /// </summary>
    public abstract class BaseObstacleManager : MonoBehaviour
    {
        [Header("Prefab References")]
        [Tooltip("Stationary obstacle prefab.")]
        public GameObject stationaryPrefab;

        [Tooltip("Moving obstacle prefab (must include a MovingObstacle component).")]
        public GameObject movingPrefab;

        [Header("Spawn Configuration")]
        public Vector3 spawnArea = new Vector3(8, 0, 8);
        public float groundY = 0.5f;

        // Track all active obstacles for cleanup/reuse
        protected readonly List<GameObject> activeObstacles = new List<GameObject>();

        /// <summary>
        /// Spawns a single obstacle prefab at a random position.
        /// </summary>
        protected GameObject SpawnObstacle(GameObject prefab)
        {
            Vector3 pos = new Vector3(
                Random.Range(-spawnArea.x, spawnArea.x),
                groundY,
                Random.Range(-spawnArea.z, spawnArea.z)
            );

            GameObject obj = Instantiate(prefab, pos, Quaternion.identity);
            activeObstacles.Add(obj);
            return obj;
        }

        /// <summary>
        /// Removes all currently active obstacles.
        /// </summary>
        public virtual void ClearObstacles()
        {
            foreach (var o in activeObstacles)
                if (o != null) Destroy(o);
            activeObstacles.Clear();
        }

        /// <summary>
        /// Hook for subclasses to define how obstacles are spawned.
        /// </summary>
        public abstract void GenerateObstacles(int difficultyLevel);
    }
}