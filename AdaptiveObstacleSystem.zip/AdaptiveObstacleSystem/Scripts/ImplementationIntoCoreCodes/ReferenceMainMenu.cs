using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class ReferenceMainMenu : MonoBehaviour
{
    public void OnClickLoadScene(int sceneIndex)
    {
        // ***For Game Obstacles***
        int levelNumber = sceneIndex;
        int difficulty = sceneIndex;  // Currently redundant but can be expanded to set difficulty apart from level
        DifficultyManager.Instance.SetLevel(levelNumber);
        DifficultyManager.Instance.SetDifficulty(difficulty);
        // ***End Game Obstacle Addition***
        
        SceneManager.LoadScene(sceneIndex);
    }
    
    public void OnClickQuit()
    {
        Application.Quit();
        //Show this message in the editor so we know this method is being called
        Debug.Log("Main Menu Quit.");
    }
}
