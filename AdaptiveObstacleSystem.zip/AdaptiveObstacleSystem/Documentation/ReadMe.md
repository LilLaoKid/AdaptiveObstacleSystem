﻿**Identifying information:
Full name - William Soukthavong
Student ID - 2481674
Chapman email - soukthavong@chapman.edu
Course number and section - GAME-244-01
Assignment or exercise number - Roll-A-Ball

Obstacle System v1.0
---------------------

This package provides a reusable obstacle spawning system for Unity.

Features:
- Adaptive obstacle generation (stationary + moving)
- Difficulty scaling via DifficultyManager
- Manual spawn method (SpawnObstacleAt)
- Optional editor tool for placement
- Initially it spawns randomly place obstacles (amount depends on level).
- Random spawn can be turned off and obstacles can be placed manually.

Usage:
1. Drop "AdaptiveObstacleSystem" folder into your "Assets" folder.
2. Drag the "DifficultyManager" prefab into your "MainMenu" scene.
3. Drag the "AdaptiveObstacleManager" prefab into your "level" scene(s).
4. Assign stationary and moving prefabs.
5. Adjust difficulty level through DifficultyManager or code.
6. Wire "AdaptiveObstacleManager" to "GameController" Game Object.
7. Update your core codes "MainMenu" and "GameController" with the required codes.
   * Refer to "Reference" codes provided and look for ***~*** comments
8. Call SpawnObstacleAt() to place custom obstacles in your code.
9. Editor can also be used to manually place obstacles directly to scene.
   * Click on the "AdaptiveObstacleManager" and look for the editor component in the inspector.
   * Chose coordinate values (x,y,z) and click spawn station/moving obstacle.

API Reference:
--------------
AdaptiveObstacleManager.SpawnObstacleAt(Vector3 position, Quaternion rotation, bool isMoving = false)

Requires Unity 6000.2.7f2 (tested in 6000.2.7f2)

Notes:
- I used a free Assets pack from the unity store that came with prefabs already built that I could just drop in.
- https://assetstore.unity.com/packages/templates/packs/obstacle-course-pack-178169
- If you want to do the same, BE WARNED, you will have a compilation error pop up in your game.
- You will need to go into the ObstacleCoursePack/Scripts and look for the "Rotator" script.
- Rename it, I choose "ObstacleRotator", then OPEN it and rename the class as well to the same thing.
- That should fix the compiling error that pops up due to duplicate classes.
- You are also free to make or import your own obstacle prefabs and use those instead.
